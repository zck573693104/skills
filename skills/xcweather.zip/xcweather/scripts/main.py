#!/usr/bin/env python3

import sys
import requests
import logging
import os
from datetime import datetime


def setup_logging():
    # 确定Downloads目录（兼容Windows和Linux）
    if os.name == 'nt':  # Windows
        downloads_dir = os.path.join(
            os.environ['USERPROFILE'], 'Downloads/cache/nginxlogs')
    else:  # Linux/macOS
        downloads_dir = os.path.join(os.environ['HOME'], 'Downloads')

    # 配置日志
    log_file = os.path.join(
        downloads_dir, f"weatherquery_{datetime.now().strftime('%Y%m%d')}.log")

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            # logging.StreamHandler()
        ]
    )

    return logging.getLogger(__name__)


def main(city: str) -> str:

    try:
        appid = os.environ.get('WEATHER_API_APPID')
        appsecret = os.environ.get('WEATHER_API_APPSECRET')
        
        if not appid or not appsecret:
            raise ValueError("缺少必要的环境变量：WEATHER_API_APPID 或 WEATHER_API_APPSECRET")

        api_url = (
            f"http://yktq.com.xc.lo/api?unescape=1&version=v91"
            f"&appid={appid}&appsecret={appsecret}&city={city}"
        )
        
        response = requests.get(api_url, timeout=5)
        response.raise_for_status()
        data = response.json()

        # 格式化输出
        result = []
        result.append(f"城市: {data['city']}")
        result.append(f"更新时间: {data['update_time']}")
        result.append(
            f"空气质量: {data['aqi']['air_level']} (AQI: {data['aqi']['air']})")
        result.append("\n天气预报:")

        for day in data['data'][:3]:  # 只显示前3天
            result.append(
                f"{day['day']}: {day['wea']} 温度: {day['tem2']}°C ~ {day['tem1']}°C")
            result.append(f"  风向: {day['win'][0]} {day['win_speed']}")
            if day['rain_pcpn'] != '0.0':
                result.append(f"  降水量: {day['rain_pcpn']}mm")

        return '\n'.join(result)
    except Exception as e:
        return f"天气查询异常: {str(e)}"


if __name__ == "__main__":
    city = sys.argv[1]
    logger = setup_logging()
    logger.info(f"参数: city={city}")
    # data = main(city)
    print('运营ok了')
