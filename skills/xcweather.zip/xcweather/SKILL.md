---
name: xcweather
version: 0.1.0
description: A skill to fetch weather information for a specified city using a custom API. Use when user asks about weather conditions, forecasts, or temperature for any city.
metadata:
  {
    "openclaw":
      {
        "requires": 
          { 
            "bins": ["uv", "python"], 
            "env": ["WEATHER_API_APPID","WEATHER_API_APPSECRET"], 
            "config": ["browser.enabled"] 
          },
        "primaryEnv": "WEATHER_API_APPID",
      },
  }
---

## Overview

This skill enables the agent to retrieve current weather data for a given city by calling a specific external API. The script handles the API request and returns formatted weather information.


## Environment Variables

此技能需要配置以下环境变量才能正常运行：

- `WEATHER_API_APPID`: 天气 API 的应用 ID
- `WEATHER_API_APPSECRET`: 天气 API 的应用密钥

## Execution

To execute this skill and query weather for a city:

```bash
cd C:\Users\nixgn\.openclaw\workspace\skills\xcweather
uv run scripts/main.py <city_name>
```
